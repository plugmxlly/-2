﻿using System;
using System.IO;
using System.Text;


namespace ConsoleApp5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Типы автомобилей");
            Console.WriteLine();
            
            Console.WriteLine(DatabaseRequests.GetTypeCarQuery());
            Console.WriteLine();
            
            Console.WriteLine("Добавить новый тип автомобиля?");
            
            string que = Console.ReadLine();
            
            if (que == "Yes" || que == "Да")
            {
                Console.WriteLine("Введите тип автомобиля");
                DatabaseRequests.AddTypeCarQuery(Console.ReadLine());
                DatabaseRequests.GetTypeCarQuery();
            }
            
            Console.WriteLine("Автомобили");
            Console.WriteLine(DatabaseRequests.GetCarQuery());
            Console.WriteLine();
            
            
            Console.WriteLine(":Добавить новый автомобиль?");
            
            string que1 = Console.ReadLine();
            
            if (que1 == "Yes" || que1 == "Да")
            {
                Console.WriteLine("id автомобиля, Название автомобиля, Штатное название, Кол-во мест");
                DatabaseRequests.AddCarQuery(int.Parse(Console.ReadLine()), Console.ReadLine(), Console.ReadLine(), int.Parse(Console.ReadLine()));
                DatabaseRequests.GetCarQuery();
            }
            
            Console.WriteLine("Водители");
            Console.Write(DatabaseRequests.GetDriverQuery());
            Console.WriteLine();
            
            Console.WriteLine("Добавить нового водителя?");
            
            string que2 = Console.ReadLine();
            
            if (que2 == "Yes" || que2 == "Да")
            {
                Console.WriteLine("Имя, Фамилия, Дата рождения водителя");
                DatabaseRequests.AddDriverQuery(Console.ReadLine(), Console.ReadLine(), DateTime.Parse(Console.ReadLine()));
            }
            
            Console.WriteLine("Права");
            DatabaseRequests.GetRightsCategoryQuery();
            
            Console.WriteLine();
            Console.WriteLine("Добавить новую категорию прав?");
            
            string que3 = Console.ReadLine();
            
            if (que3 == "Yes" || que3 == "Да")
            {
                Console.WriteLine("Название категории прав");
                DatabaseRequests.AddRightsCategoryQuery(Console.ReadLine());
                Console.WriteLine();
                DatabaseRequests.GetRightsCategoryQuery();
            }
            
            Console.WriteLine("Водители и их категории прав");
            DatabaseRequests.GetDriverRightsCategoryQuery();
            
            Console.WriteLine();
            Console.WriteLine("Хотите добавить новую категорию прав водителю?");
            
            string que4 = Console.ReadLine();
            
            if (que4 == "Yes" || que4 == "Да")
            {
                Console.WriteLine("id водителя, id категории прав");
                DatabaseRequests.AddDriverRightsCategoryQuery(int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()));
            }
            
            Console.WriteLine("Маршруты");
            DatabaseRequests.GetItineraryQuery();
            Console.WriteLine();
            
            Console.WriteLine("Добавить новый маршрут?");
            
            string que5 = Console.ReadLine();

            if (que5 == "Yes" || que5 == "Да")
            {
                Console.WriteLine("Название маршрута");
                DatabaseRequests.AddItineraryQuery(Console.ReadLine());
                Console.WriteLine();
                DatabaseRequests.GetItineraryQuery();
            }
            
            Console.WriteLine("Рейсы");
            Console.WriteLine(DatabaseRequests.GetRouteQuery());
            Console.WriteLine();
            Console.WriteLine("Добавить новый рейс?");
            
            string que6 = Console.ReadLine();
            
            if (que6 == "Yes" || que6 == "Да")
            {
                Console.WriteLine("id водителя, id машины, id маршрута, число пассажиров");
                DatabaseRequests.AddRouteQuery(Convert.ToInt32(Console.ReadLine()), Convert.ToInt32(Console.ReadLine()), 
                    Convert.ToInt32(Console.ReadLine()), Convert.ToInt32(Console.ReadLine()));
                Console.WriteLine();
                Console.WriteLine(DatabaseRequests.GetRouteQuery());
            }
        }
    }
}